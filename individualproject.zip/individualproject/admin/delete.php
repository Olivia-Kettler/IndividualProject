<?php
include('classes.php');
new $order=new User();
$order->deleteOrder($_POST['id']);
?>
<html>
<a href="index.php">Home</a>
</html>