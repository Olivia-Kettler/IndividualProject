<?php
include('classes.php');
$settings=[
	'host'=>'localhost',
	'db'=>'combowebsite',
	'user'=>'root',
	'password'=>''
];

$opt=[
	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES => false
];
//connecting to database
$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
$settings['user'],$settings['password'],$opt);
$info=$pdo->query('SELECT * FROM cart WHERE ID='.$_POST['id'].';');

$order= new User();

	$order->request=$_POST['request'];
	$order->username=$_POST['username'];
	$order->comboName=$_POST['order'];
	$order->quantity=$_POST['quantity'];
	$order->editOrder($_POST['id']);
?>
<html>
		
	<form action="edit.php" method="POST">
	Username:
	<input type="text" name="name" value="<?=$info['username']?>"><br>
	Order:
	<br>
	<input type="radio" name="order" value="Burger Combo">
	<label for="Burger Combo">Burger Combo</label><br>
	<input type="radio" name="order" value="Shake Combo">
	<label for="Shake Combo">Shake Combo</label><br>
	<input type="radio" name="order" value="Fries Combo">
	<label for="Fries Combo">Fries Combo</label><br>
	How many?
	<br>
	<input type="number" name="quantity" value="<?=$info['quantity']?>"><br>
	Special Requests:
	<br>
	<textarea name="request" rows="5" cols="30"><?=$info['request']?></textarea>
	<br>
	<button type="submit">Submit</button><br><br>
	<a href="index.php">Home</a>
	</form>
</html>