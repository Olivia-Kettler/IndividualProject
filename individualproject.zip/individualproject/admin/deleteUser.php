<?php
include('classes.php');
new $user=new User();
$user->deleteUser($_POST['id']);
?>
<html>
<a href="index.php">Home</a>
</html>