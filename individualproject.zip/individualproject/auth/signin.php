<?php
session_start();
include('../classes.php');
$settings=[
	'host'=>'localhost',
	'db'=>'combowebsite',
	'user'=>'root',
	'password'=>''
];

$opt=[
	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES => false
];
//connecting to database
$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
$settings['user'],$settings['password'],$opt);

//executing and processing results
$result=$pdo->query('SELECT * FROM account');

function signin(){
	if(count($_POST)>0){
		$password=trim($_POST['password']);
		$email=$_POST['email'];
		//if email is valid
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			return 'The email you entered is not valid';
		}
		//if password isn't 8 characters
		if(strlen($password) < 8){
			return "The password is not 8 characters.";
		}
		while($record=$result->fertch()){
			//if email matches
			if($_POST['email'] == $record['email']){
				//checks if password matches
				if($_POST['password'] == $record['password']){
					$_SESSION['user/email']=$record['username'];
					return;
				}else{
					return "Password incorrect"
				}
			}
		}
		return 'This email is not associated with any account. Please <a href="auth/signup.php">Sign Up</a>';
	}
}
	if(count($_POST)>0){
		$error=signin();
		if(isset($error{0})) echo $error;
		else  header('location: ../index.php');
	}
?>
<form action="signin.php" method="POST">
E-Mail
<input type="email" name="email" required><br>
Password
<input type="password" name="password" required minlength="8"><br>
<button type="submit">Sign In</button>
Don't have an account? <a href="auth/signup.php">Create an account.</a>
</form>