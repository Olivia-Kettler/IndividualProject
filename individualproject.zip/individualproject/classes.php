<?php
class User{
	public $email;
	public $password;
	public $username;
	public $name;
	
	public $quantity;
	public $comboName;
	public $request;
	
	public function createUser(){
		$settings=[
		'host'=>'localhost',
		'db'=>'combowebsite',
		'user'=>'root',
		'password'=>''
		];

		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		//connecting to database
		$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
		$settings['user'],$settings['password'],$opt);
		
		$query='INSERT INTO users (username,name,email,password)
		VALUES (?,?,?,?);';
		$q=$pdo->prepare($query);
		$q->execute([$this->username,$this->name,
		$this->email,hash_password($this->password,PASSWORD_DEFAULT)]);
		echo $pdo->lastInsertId();
	}
	public function editUser($id){
		$settings=[
		'host'=>'localhost',
		'db'=>'combowebsite',
		'user'=>'root',
		'password'=>''
		];

		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		//connecting to database
		$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
		$settings['user'],$settings['password'],$opt);
		
		$query='UPDATE account SET username=?, name=?, email=?, password=? WHERE ID='.$id.';';
		$q=$pdo->prepare($query);
		$q->execute([$this->username,$this->name,
		$this->email,hash_password($this->password,PASSWORD_DEFAULT)]);
	}
	public function createOrder(){
		$settings=[
		'host'=>'localhost',
		'db'=>'combowebsite',
		'user'=>'root',
		'password'=>''
		];

		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		//connecting to database
		$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
		$settings['user'],$settings['password'],$opt);
		$query='INSERT into cart (username,comboName,quantity,request,total) 
		VALUES(?,?,?,?,(SELECT price FROM combos)*?;';
		$q=$pdo->prepare($query);
		$q->execute([this->username,$this->comboName,$this->quantity,$this->request,
		$this->quantity]);
		echo $pdo->lastInsertId();
	}
	public function editOrder($id){
		$settings=[
		'host'=>'localhost',
		'db'=>'combowebsite',
		'user'=>'root',
		'password'=>''
		];

		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		//connecting to database
		$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
		$settings['user'],$settings['password'],$opt);	
		$query='UPDATE cart SET username=?,comboName=?,quantity=?,request=?,
		total=(SELECT price FROM combos)*quantity WHERE ID='.$id.';';
		$q=$pdo->prepare($query);
		$q->execute([this->username,$this->comboName,$this->quantity,$this->request,
		$this->quantity]);
	}
	public function deleteOrder($id){
		$settings=[
		'host'=>'localhost',
		'db'=>'combowebsite',
		'user'=>'root',
		'password'=>''
		];

		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		//connecting to database
		$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
		$settings['user'],$settings['password'],$opt);	
		$query='DELETE FROM cart WHERE ID='.$id.';';
		$q=$pdo->prepare($query);
		$q->execute();
	}
		public function deleteUser($id){
		$settings=[
		'host'=>'localhost',
		'db'=>'combowebsite',
		'user'=>'root',
		'password'=>''
		];

		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		//connecting to database
		$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
		$settings['user'],$settings['password'],$opt);	
		$query='DELETE FROM account WHERE ID='.$id.';';
		$q=$pdo->prepare($query);
		$q->execute();
	}
}