<?php
	$settings=[
	'host'=>'localhost',
	'db'=>'combowebsite',
	'user'=>'root',
	'password'=>''
	];

	$opt=[
	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES => false
	];
	//connecting to database
	$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
	$settings['user'],$settings['password'],$opt);
	$info=$pdo->query('SELECT * FROM account WHERE ID='.$_GET['id']);
	
	function signup(){
	if(count($_POST) >0){

		$password=trim($_POST['password']);
		$email=$_POST['email'];
		//if email is valid
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			return "The email you entered is not valid";
		}
		//if password isn't 8 characters
		if(strlen($password) < 8){
			return "The password is not 8 characters.";
		}
		//add user to database
		$user->email=$_POST['email'];
		$user->username=$_POST['username'];
		$user->name=$_POST['name'];
		$user->password=$_POST['password'];
		$user->editUser($_POST['id']);
		return;
	}
}

if(count($_POST)>0){
	$error=signup();
	if(isset($error{0})) echo $error;
		else echo 'changes saved';
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>User Area</title>
	
  </head>
  <body>
  <div class="container">
    <h1>Manage Account</h1>
	<a type="button" href="users/index.php" class="btn btn-primary btn-lg">Back to User Home</a>
	<br>
	<form action="users.php" method="POST">
		Username
		<input type="text" name="username" value="<?=$info['username']?>"required><br>
		Name
		<input type="text" name="name" value="<?=$info['name']?>"><br>
		E-Mail
		<input type="email" name="email" value="<?=$info['email']?>"required><br>
		Password
		<input type="password" name="password" value="<?=$info['password']?>" required minlength="8"><br>
		<button type="submit">Edit</button>
	</form>
	
	
	</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>